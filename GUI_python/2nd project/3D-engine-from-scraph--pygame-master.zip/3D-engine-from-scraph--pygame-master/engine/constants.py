Size = 1000, 1000
Width, Height = Size
BackgroundColor = (0 , 0, 0)
aspect = Height/Width #aspect ratio

clipping = 1.5
mouse_sensitivity = 200
Zoffset = 7

dim = 0.01 #the darkest spot on the screen

#colors
blue = (0, 0, 255)
orange = (255, 160, 0)
black = (0, 0, 0)
white = (255, 255, 255)
red = (255, 0, 0)
green = (0, 255, 0)
yellow = (0, 255, 255)

# axis_offset = 50
# axis_positions = {
#     "CENTER": (Width//2, Height//2),
#     "TOP-LEFT": (axis_offset, axis_offset),
#     "TOP-RIGHT": (Width-axis_offset, axis_offset),
#     "BOTTOM-LEFT": (axis_offset, Height-axis_offset),
#     "BOTTOM-RIGHT": (Width-axis_offset, Height-axis_offset)
# }
